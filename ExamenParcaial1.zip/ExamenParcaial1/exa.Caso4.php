<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Título de la página</title>
</head>
<body>
    <header>
        <h3>PAPELERÍA ONLINE</h3>
    </header>
    <section>
        <form action="exa.Caso4.php" method="post">

        <tableborder="0" cellpadding="0" cellspacing="0">

        </table>

        </form>
    </section>
    <footer>
        <h6>Todos los derechos reservados @Dany</h6>
    </footer>
</body>
</html>